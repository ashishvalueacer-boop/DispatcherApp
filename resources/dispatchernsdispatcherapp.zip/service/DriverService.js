sap.ui.define(["./ApiService"],function(e){"use strict";return{getAll(){return e.get("/GetDrivers")}}});
//# sourceMappingURL=DriverService.js.map