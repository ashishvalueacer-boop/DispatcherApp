sap.ui.define(["./ApiService"],function(e){"use strict";return{getAll(){return e.get("/GetVehicles")}}});
//# sourceMappingURL=VehicleService.js.map