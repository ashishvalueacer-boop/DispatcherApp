sap.ui.define(["sap/ui/core/UIComponent","sap/ui/model/json/JSONModel","dispatcherns/dispatcherapp/model/models"],(e,t)=>{"use strict";return e.extend("dispatcherns.dispatcherapp.Component",{metadata:{manifest:"json",interfaces:["sap.ui.core.IAsyncContentCreation"]},init(){e.prototype.init.apply(this,arguments);
//         { id: "DRV001", name: "John Smith", location: "Mumbai", status: "Available", license: "Valid", vehicle: "MH01 AB 1234", type: "Contract" },
//         { id: "DRV002", name: "Peter Brown", location: "Pune", status: "Available", license: "Valid", vehicle: "MH12 CD 4567", type: "Permanent" },
//         { id: "DRV003", name: "Raj Kumar", location: "Mumbai", status: "Available", license: "Valid", vehicle: "MH04 EF 7890", type: "Contract" },
//         { id: "DRV004", name: "Mike Wilson", location: "Nashik", status: "Available", license: "Valid", vehicle: "MH15 GH 2345", type: "Permanent" },
//         { id: "DRV005", name: "Suresh Patel", location: "Surat", status: "On Break", license: "Valid", vehicle: "GJ05 JK 6789", type: "Contract" },
//         { id: "DRV006", name: "Amit Shah", location: "Pune", status: "Available", license: "Valid", vehicle: "MH12 KL 1234", type: "Permanent" },
//         { id: "DRV007", name: "Vikram Joshi", location: "Mumbai", status: "Available", license: "Valid", vehicle: "MH01 MN 5678", type: "Contract" }
//         { vehid: "VEH001", license: "Valid", vehicle: "MH01 AB 1234", type: "Contract" },
//         { vehid: "VEH002", license: "Valid", vehicle: "MH12 CD 4567", type: "Permanent" },
//         { vehid: "VEH003", license: "Valid", vehicle: "MH04 EF 7890", type: "Contract" },
//         { vehid: "VEH004", license: "Valid", vehicle: "MH15 GH 2345", type: "Permanent" },
//         { vehid: "VEH005", license: "Valid", vehicle: "GJ05 JK 6789", type: "Contract" },
//         { vehid: "VEH006", license: "Valid", vehicle: "MH04 EF 7890", type: "Contract" },
//         { vehid: "VEH007", license: "Valid", vehicle: "MH15 GH 2345", type: "Permanent" },
//         { vehid: "VEH008", license: "Valid", vehicle: "GJ05 JK 6789", type: "Contract" },
//         { vehid: "VEH009", license: "Valid", vehicle: "MH15 GH 2345", type: "Permanent" },
//         { vehid: "VEH0010", license: "Valid", vehicle: "GJ05 JK 6789", type: "Contract" },
//         { vehid: "VEH0011", license: "Valid", vehicle: "MH15 GH 2345", type: "Permanent" },
//         { vehid: "VEH0012", license: "Valid", vehicle: "GJ05 JK 6789", type: "Contract" },
this.getRouter().initialize()}})});
//# sourceMappingURL=Component.js.map